from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def web_selecter():

    if request.method == "POST":
            req = request.form
            web_num = ["num"]
            if web_num == 1:
                        @app.route("/", methods=["GET", "POST"])
                        def sign_up():
                            title = "web1"
                            heading = "Home Page"
                            if request.method == "POST":
                                req = request.form
                                background = req["background"]
                                bgcolour = req["bg-colour"]
                                para1 = req["para1"]
                                para2 = req["para2"]
                                para3 = req["para3"]
                                return render_template("/index.html", background=background, title=title, heading=heading, headback=bgcolour, para1=para1, para2=para2, para3=para3)
                            return render_template("/sign_up.html")

            elif web_num == 2:
                        @app.route("/test", methods=["GET", "POST"])
                        def test():
                            title = "webtest"
                            heading = "test page"
                            if request.method == "POST":
                                req = request.form
                                videourl = req["videourl"]
                                background = req["background"]
                                para1 = req["para1"]
                                para2 = req["para2"]
                                return render_template("/temp2.html", para1=para1, para2=para2, background=background, videourl=videourl)
                            return render_template("/test.html")
    return render_template("/web_selecter.html")
if __name__ == '__main__':
    app.run(debug=True)

